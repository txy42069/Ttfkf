### Warning: Use of these miners is not officialy supported by us

If something doesn't work and/or goes wrong try to get in contact with the person that made it to fix the issue or report the bug to be fixed.
You can request to add your miner here by submitting a pull request.

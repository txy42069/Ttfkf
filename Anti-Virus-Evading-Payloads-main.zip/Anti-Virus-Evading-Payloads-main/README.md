# :triangular_flag_on_post: Anti-Virus-Evading-Payloads:

During the exploitation phase of a pen test or ethical hacking engagement, you will ultimately need to try to cause code to run on target system computers. Whether accomplished by phishing emails, delivering a payload through an exploit, or social engineering, running code on target computers is part of most penetration tests. That means that you will need to be able to bypass antivirus software or other host-based protection for successful exploitation. The most effective way to avoid antivirus detection on your target's computers is to create your own customized backdoor. Here is a simple way to evade anti-virus software when creating backdoors!

![Blog_Detail_Generic_Image](https://user-images.githubusercontent.com/72598486/150626168-579a22d1-efe0-4a79-8291-9b39b835055a.jpg)

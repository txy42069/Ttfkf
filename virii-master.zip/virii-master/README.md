# virii
Collection of ancient computer virus source codes (mostly). 
There should be around 2000 files in this repository with a few being Pascal source codes or assembled [COM](https://en.wikipedia.org/wiki/COM_file) files. A portion of the source codes are also result of reverse engineering and 
most if not all of it were created for DOS and/or Win9x.

I had these files laying around an old hard drive since ages ago and decided to share. They were once included in an issue of a magazine from the early 2000s called H4CK3R by Digerati (a publisher from Brazil which had lots of interesting magazines and books about hacktivism and related topics).

The content of this repository is for educational purposes, I am not responsible for the misuse of it.
